﻿using CaseStudy.Model;
using IngenioCaseStudy.DataAccess;

namespace CaseStudy.Operations
{
    public class CategoryLevel
    {
        private readonly List<DataSetModel> _dataset;
        public CategoryLevel(List<DataSetModel> dataset)
        {
            _dataset = dataset;
        }

        public string ExecuteCategoryLevel()
        {
            string result = string.Empty;


            Console.WriteLine("Enter any Level (1-3):");
            if (int.TryParse(Console.ReadLine(), out int level))
            {
                var categoryIds = GetCategoryIdsByLevel(level);

                if (categoryIds.Count > 0)
                {
                    result = string.Join(",", categoryIds);
                }
                else
                {
                    result = "No results found. Try entering level between 1 to 3 only.";
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a numeric value.");
                result = ExecuteCategoryLevel();
            }

            return result;
        }

        private List<int> GetCategoryIdsByLevel(int level)
        {
            var currentLevelIds = _dataset
                .Where(x => x.ParentCategoryId == -1)
                .Select(x => x.CategoryId)
                .ToList();

            //level greater than 1 means we need to traverse down the hierarchy.
            for (int i = 1; i < level; i++)
            {
                currentLevelIds = GetChildCategoryIds(currentLevelIds);
            }

            return currentLevelIds;
        }

        private List<int> GetChildCategoryIds(List<int> parentIds)
        {
            return _dataset
                .Where(x => parentIds.Contains(x.ParentCategoryId))
                .Select(x => x.CategoryId)
                .OrderBy(id => id)
                .ToList();
        }
    }
}
