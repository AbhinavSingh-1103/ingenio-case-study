﻿using CaseStudy.Model;
using IngenioCaseStudy.DataAccess;
using System.Data;

namespace CaseStudy.Operations
{
    public class MainOperations
    {
        private readonly CategoryDetails _categoryDetails;
        private readonly CategoryLevel _categoryLevel;
        public MainOperations()
        {
            var dataSetRepository = new DataSetRepository();
            var _dataset = dataSetRepository.GetDataSets();

            _categoryDetails = new CategoryDetails(_dataset);
            _categoryLevel = new CategoryLevel(_dataset);
        }

        public void Perform()
        {
            string output = string.Empty;

            Console.WriteLine("Enter case number (1 or 2) which you want to execute:\nCASE 1: Get Category Details based on Category Id.\nCASE 2: Get Category Id based on Level.");

            if (int.TryParse(Console.ReadLine(), out int caseNumber))
            {
                switch (caseNumber)
                {
                    case 1:
                        output = _categoryDetails.ExecuteCategoryDetails();
                        break;
                    case 2:
                        output = _categoryLevel.ExecuteCategoryLevel();
                        break;
                    default:
                        Console.WriteLine("Invalid case selected.");
                        Console.WriteLine("Enter case number (1 or 2) which you want to execute.");
                        Perform();
                        break;
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a numeric value.");
                Perform();
            }

            Console.WriteLine(output);
            ContinueOrExit();
        }

        private void ContinueOrExit()
        {
            Console.WriteLine("Do you want to continue? (y/n):");
            var input = Console.ReadLine();
            if (!string.IsNullOrEmpty(input) && input.Trim().ToLower() == "y")
            {
                Perform();
            }
            else
            {
                Console.WriteLine("Exiting. Press any key to close...");
                Console.ReadKey();
            }
        }
    }
}
