﻿using CaseStudy.Model;
using IngenioCaseStudy.DataAccess;

namespace CaseStudy.Operations
{
    public class CategoryDetails
    {
        private readonly List<DataSetModel> _dataset;
        public CategoryDetails(List<DataSetModel> dataset)
        {
            _dataset = dataset;
        }

        public string ExecuteCategoryDetails()
        {
            string result = string.Empty;
            var datasetToString = string.Join(",", _dataset.Select(x => x.CategoryId));
            
            Console.WriteLine($"Enter Category Id from: [{datasetToString}]");
            if (int.TryParse(Console.ReadLine(), out int categoryId))
            {
                result = CommaDelimitedString(categoryId);
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a numeric value.");
                result = ExecuteCategoryDetails();
            }

            return result;
        }

        private string CommaDelimitedString(int categoryId)
        {
            var outputMessage = string.Empty;

            var dataSetModel = GetDataSetModel(categoryId);
            
            if (dataSetModel != null)
            {
                outputMessage = $"Category Id: {dataSetModel.CategoryId}, Name: {dataSetModel.Name}, Keywords: {dataSetModel.Keywords}";
            }
            else
            {
                outputMessage = $"Category Id: {categoryId} not found.";
            }

            return outputMessage;
        }

        private DataSetModel GetDataSetModel(long categoryId)
        {
            var dataSetModel = _dataset.FirstOrDefault(x => x.CategoryId == categoryId);

            if (dataSetModel != null && string.IsNullOrEmpty(dataSetModel.Keywords))
            {
                var newDataSetModel = GetDataSetModel(dataSetModel.ParentCategoryId);
                if (newDataSetModel != null)
                {
                    dataSetModel.Keywords = newDataSetModel.Keywords;
                }
            }

            return dataSetModel;
        }
    }
}
