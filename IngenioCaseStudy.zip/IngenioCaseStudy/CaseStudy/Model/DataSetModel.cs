﻿namespace CaseStudy.Model
{
    public class DataSetModel
    {
        public int CategoryId { get; set; }
        public int ParentCategoryId { get; set; }
        public string Name { get; set; }
        public string Keywords { get; set; }
    }
}
