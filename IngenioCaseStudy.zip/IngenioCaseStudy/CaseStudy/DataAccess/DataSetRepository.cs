﻿using CaseStudy.Model;

namespace IngenioCaseStudy.DataAccess
{
    public class DataSetRepository
    {
        public List<DataSetModel> GetDataSets()
        {
            int[] categoryId = [100, 200, 101, 102, 201, 103, 202, 109];
            int[] parentCategoryId = [-1, -1, 100, 100, 200, 101, 201, 101];
            string[] name = ["Business", "Tutoring", "Accounting", "Taxation", "Computer", "Corporate Tax", "Operating System", "Small Business Tax"];
            string[] keywords = ["Money", "Teaching", "Taxes"];

            List<DataSetModel> dataList = new List<DataSetModel>();
            for (int i = 0; i < categoryId.Length; i++)
            {

                DataSetModel data = new DataSetModel()
                {
                    CategoryId = categoryId[i],
                    ParentCategoryId = parentCategoryId[i],
                    Name = name[i],
                    Keywords = i < keywords.Length ? keywords[i] : null
                };

                dataList.Add(data);
            }

            return dataList;
        }
    }
}
