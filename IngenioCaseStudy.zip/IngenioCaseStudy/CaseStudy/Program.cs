﻿// See https://aka.ms/new-console-template for more information

using CaseStudy.Operations;



MainOperations main = new MainOperations();
main.Perform();


